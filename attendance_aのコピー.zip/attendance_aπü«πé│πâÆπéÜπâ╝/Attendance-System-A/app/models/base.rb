class Base < ApplicationRecord
end
